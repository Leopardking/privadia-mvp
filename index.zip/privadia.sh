DISPLAY=:0 npm run start
