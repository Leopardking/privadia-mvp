import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions  } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import {LoginService} from "../login/login.service";

@Injectable()
export class ProposalsService {
	private apiUrl: string = 'http://privadia-mvp-api-dev.azurewebsites.net';
	// private apiUrl:string = 'http://privadia-mvp-api-2-dev.azurewebsites.net';
	private token: string = localStorage.getItem('id_token');

	constructor ( private http: Http,
				  private loginService: LoginService ) {
		console.log('Load Proposals Service');
	}

	public createProposals(data) {
		if(!this.loginService.getPermission('Proposals/Post'))
			return Observable.throw(null);

		let header = new Headers( {'Authorization': this.token} );
		let options = new RequestOptions( {headers: header} );

		return this.http.post( `${this.apiUrl}/api/Proposals`, data, options )
            .map(this.extractData)
            .catch(this.handleError);
	}

	public saveProposals(data) {
		// if(!this.loginService.getPermission('Proposals/Put'))
		// 	return Observable.throw(null);

		let header = new Headers( {'Authorization': this.token} );
		let options = new RequestOptions( {headers: header} );

		return this.http.put( `${this.apiUrl}/api/Proposals`, data, options )
            .map(this.extractData)
            .catch(this.handleError);
	}

	public submitProposals(data) {
		if(!this.loginService.getPermission('Proposals/Submit'))
			return Observable.throw(null);

		let header = new Headers( {'Authorization': this.token} );
		let options = new RequestOptions( {headers: header} );

		return this.http.post( `${this.apiUrl}/api/Proposals/Submit`, data, options )
            .map(this.extractData)
            .catch(this.handleError);
	}


	public acceptProposals(data) {
		if(!this.loginService.getPermission('Proposals/Accept'))
			return Observable.throw(null);

		let header = new Headers( {'Authorization': this.token} );
		let options = new RequestOptions( {headers: header} );

		return this.http.post( `${this.apiUrl}/api/Proposals/Accept`, data, options )
            .map(this.extractData)
            .catch(this.handleError);
	}

	private extractData(res:Response) {
		let body = res.json();

	    return body || { };
	}

	private handleError(error: Response | any) {
		let errMsg: string;
	    if (error instanceof Response) {
	      const body = error.json() || '';
	      const err = body.error || JSON.stringify(body);
	      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
	    } else {
	      errMsg = error.message ? error.message : error.toString();
	    }

	    return Observable.throw(errMsg);
	}
}