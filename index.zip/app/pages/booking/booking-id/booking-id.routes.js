"use strict";
var booking_id_component_1 = require('./booking-id.component');
exports.MODULE_ROUTES = [
    { path: ':id', component: booking_id_component_1.BookingIdComponent }
];
exports.MODULE_COMPONENTS = [
    booking_id_component_1.BookingIdComponent,
];
//# sourceMappingURL=booking-id.routes.js.map