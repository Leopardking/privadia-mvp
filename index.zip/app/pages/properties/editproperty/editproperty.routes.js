"use strict";
var editproperty_component_1 = require("./editproperty.component");
exports.MODULE_ROUTES = [
    { path: '', component: editproperty_component_1.EditpropertyComponent, pathMatch: 'full' }
];
exports.MODULE_COMPONENTS = [
    editproperty_component_1.EditpropertyComponent,
];
//# sourceMappingURL=editproperty.routes.js.map