"use strict";
var addproperty_component_1 = require("./addproperty.component");
exports.MODULE_ROUTES = [
    { path: '', component: addproperty_component_1.AddpropertyComponent, pathMatch: 'full' }
];
exports.MODULE_COMPONENTS = [
    addproperty_component_1.AddpropertyComponent,
];
//# sourceMappingURL=addproperty.routes.js.map