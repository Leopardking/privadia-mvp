"use strict";
exports.MODULE_ROUTES = [];
exports.MODULE_COMPONENTS = [];
//# sourceMappingURL=users.routes.js.map