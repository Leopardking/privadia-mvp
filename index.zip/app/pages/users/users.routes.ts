import { Route, RouterModule } from '@angular/router';

export const MODULE_ROUTES: Route[] =[
]

export const MODULE_COMPONENTS = [
]
