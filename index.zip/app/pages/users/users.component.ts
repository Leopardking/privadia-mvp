import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'users-cmp',
    templateUrl: 'users.component.html'
})

export class UsersComponent{}
