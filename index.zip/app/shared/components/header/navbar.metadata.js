"use strict";
//# sourceMappingURL=navbar.metadata.js.map