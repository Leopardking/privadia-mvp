declare function initSemanticSelect():void;
export = initSemanticSelect;
