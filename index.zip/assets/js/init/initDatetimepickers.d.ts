declare function initDatetimepickers():void;
export = initDatetimepickers;
