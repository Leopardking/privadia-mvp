declare function initFullScreenpage():void;
export = initFullScreenpage;
