declare function initFullCalendar():void;
export = initFullCalendar;
