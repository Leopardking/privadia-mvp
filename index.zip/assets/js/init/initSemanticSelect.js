if ('undefined' !== typeof module) {

    module.exports = function initSemanticSelect(){
        // Sliders for demo purpose in refine cards section
        // Sliders for demo purpose

        //console.log($(".semantic-drop-down").dropdown());
    }
}
