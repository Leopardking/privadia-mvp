if ('undefined' !== typeof module) {

    module.exports = function initTooltips(){
        //  Activate the tooltips
        $('[rel="tooltip"]').tooltip();
    }

}
