declare function initWizard():void;
export = initWizard;
