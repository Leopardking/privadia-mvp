declare function initChartsPage():void;
export = initChartsPage;
